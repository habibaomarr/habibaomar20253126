package assignment5Q2;
import java.util.Scanner;
public class assignment5Q2 {

	public static void main(String[] args) {
		
		        Scanner scanner = new Scanner(System.in);
		        char[][] board = new char[3][3];
		        System.out.print("Enter 9 cells (X or O): ");
		        for (int i = 0; i < 3; i++) {
		            for (int j = 0; j < 3; j++) {
		                board[i][j] = scanner.next().charAt(0);
		            }
		        }
		        for (int i = 0; i < 3; i++) {
		            System.out.println(board[i][0] + " " + board[i][1] + " " + board[i][2]);
		        }
		        int xCount = 0;
		        int oCount = 0;
		        for (int i = 0; i < 3; i++) {
		            for (int j = 0; j < 3; j++) {
		                if (board[i][j] == 'X') {
		                    xCount++;
		                } else if (board[i][j] == 'O') {
		                    oCount++;
		                }
		            }
		        }
		        System.out.println("X count: " + xCount);
		        System.out.println("O count: " + oCount);

		        // 3. Check if at least one row contains three X cells
		        boolean hasFullXRow = false;
		        for (int i = 0; i < 3; i++) {
		            if (board[i][0] == 'X' && board[i][1] == 'X' && board[i][2] == 'X') {
		                hasFullXRow = true;
		                break;
		            }
		        }

		        if (hasFullXRow) {
		            System.out.println("X has a full row");
		        } else {
		            System.out.println("No full X row");
		        }

		        scanner.close();
			}

}

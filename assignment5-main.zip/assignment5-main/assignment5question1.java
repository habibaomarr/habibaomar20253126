package assignment5Q1;
import java.util.Scanner;
public class assignment5question1 {

	public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        int[] nums = new int[6];
		        System.out.print("Enter 6 numbers: ");
		        for (int i = 0; i < 6; i++) {
		            nums[i] = scanner.nextInt();
		        }
		        System.out.print("Reverse: ");
		        for (int i = 5; i >= 0; i--) {
		            System.out.print(nums[i] + (i == 0 ? "" : " "));
		        }
		        System.out.println();
		        int evenSum = 0;
		        for (int i = 0; i < 6; i++) {
		            if (nums[i] % 2 == 0) {
		                evenSum += nums[i];
		            }
		        }
		        System.out.println("Sum of even numbers: " + evenSum);
		        int count = 0;
		        for (int i = 1; i < 6; i++) {
		            if (nums[i] > nums[0]) {
		                count++;
		            }
		        }
		        System.out.println("Greater than the first number: " + count);

		        scanner.close();
		    }
		}

package assignment5Q3;
import java.util.Scanner;
public class assignment5Q3 {

	public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        char[][] grid = new char[3][4];
		        System.out.print("Enter 3 words (4 letters each): ");
		        for (int i = 0; i < 3; i++) {
		            String word = scanner.next();
		            for (int j = 0; j < 4; j++) {
		                grid[i][j] = word.charAt(j);
		            }
		        }
		        for (int i = 0; i < 3; i++) {
		            System.out.println(grid[i][0] + " " + grid[i][1] + " " + grid[i][2] + " " + grid[i][3]);
		        }
		        System.out.print("Columns:");
		        for (int j = 0; j < 4; j++) {
		            String colWord = "";
		            for (int i = 0; i < 3; i++) {
		                colWord = colWord.concat(String.valueOf(grid[i][j]));
		            }
		            System.out.print(" " + colWord);
		        }
		        System.out.println();
		        int vowelCount = 0;
		        String vowels = "aeiou";
		        for (int i = 0; i < 3; i++) {
		            for (int j = 0; j < 4; j++) {
		                if (vowels.indexOf(grid[i][j]) != -1) {
		                    vowelCount++;
		                }
		            }
		        }
		        System.out.println("Vowels: " + vowelCount);

		        scanner.close();
			}
}

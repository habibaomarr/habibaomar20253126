package sheet4q2;
import java.util.Scanner;
public class sheet4q2 {
	public static double calculateDistance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter x1, y1, x2, y2: ");
        double x1 = scan.nextDouble();
        double y1 = scan.nextDouble();
        double x2 = scan.nextDouble();
        double y2 = scan.nextDouble();

        double distance = calculateDistance(x1, y1, x2, y2);

        System.out.println("Distance: " + distance);
    }
}
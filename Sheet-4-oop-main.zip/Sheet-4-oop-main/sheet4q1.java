package sheet4q1;
import java.util.Scanner;
public class sheet4q1 {
    public static int getInt(Scanner s, String prompt) {
        System.out.print(prompt);
        return s.nextInt();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int age = getInt(scanner, "Enter your age: ");
        System.out.println("Recorded Age: " + age);
        
        scanner.close();
    }
}
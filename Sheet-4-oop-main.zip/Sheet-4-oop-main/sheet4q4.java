package sheet4q4;
import java.util.Scanner;
public class sheet4q4 {

	 public static boolean isValidPassword(String password) {
	        if (password.length() < 8) {
	            return false;
	        }

	        int digits = 0;
	        int upper = 0;

	        for (int i = 0; i < password.length(); i++) {
	            char c = password.charAt(i);

	            if (!Character.isLetterOrDigit(c)) {
	                return false;
	            }
	            if (Character.isDigit(c)) {
	                digits++;
	            }
	            if (Character.isUpperCase(c)) {
	                upper++;
	            }
	        }

	        return digits >= 2 && upper >= 1;
	    }

	    public static void main(String[] args) {
	        Scanner scan = new Scanner(System.in);

	        System.out.print("Enter password: ");
	        String password = scan.nextLine();

	        if (isValidPassword(password)) {
	            System.out.println("Valid Password");
	        } else {
	            System.out.println("Invalid Password");
	        }
	    }
	}
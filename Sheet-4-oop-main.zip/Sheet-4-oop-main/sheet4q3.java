package sheet4q3;
import java.util.Scanner;
public class sheet4q3 {

	public static double computeArea(double radius) {
        return Math.PI * radius * radius;
    }

    public static double computeArea(double length, double width) {
        return length * width;
    }

    public static double computeArea(double base, double height, boolean isTriangle) {
        return 0.5 * base * height;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter radius for the circle: ");
        double radius = scan.nextDouble();
        System.out.println("Circle Area = " + computeArea(radius));

        System.out.print("Enter length and width for the rectangle: ");
        double length = scan.nextDouble();
        double width = scan.nextDouble();
        System.out.println("Rectangle Area = " + computeArea(length, width));

        System.out.print("Enter base and height for the triangle: ");
        double base = scan.nextDouble();
        double height = scan.nextDouble();
        System.out.println("Triangle Area = " + computeArea(base, height, true));
    }
}
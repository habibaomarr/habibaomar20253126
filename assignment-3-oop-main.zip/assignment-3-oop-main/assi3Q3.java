package assi3Q3;
import java.util.Scanner ;
public class assi3Q3 {

	public static void main(String[] args) {
		 System.out.print("Enter n: ");
		 Scanner Scan = new Scanner(System.in);

	       
	        int n = Scan.nextInt();

	        for (int i = 1; i <= n; i++) {
	            for (int j = 1; j <= n - i; j++) {
	                System.out.print(" ");
	            }
	            for (int k = 1; k <= i; k++) {
	                System.out.print("*");
	            }
	            System.out.println();
	        }
	    }
	}
package assi3question2;
import java.util.Scanner;
import java.util.scanner;
public class main {

	public static void main (String[] args) {
		 System.out.print("Enter n: ");
		  Scanner Scan = new Scanner(System.in);
	             int n = Scan.nextInt();
	        for (int i = 1; i <= n; i++) {
	            for (int j = 1; j <= n; j++) {
	                System.out.print((i * j) + " ");
	            }
	        }
	    }
	}
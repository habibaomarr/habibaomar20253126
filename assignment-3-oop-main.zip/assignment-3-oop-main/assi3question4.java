package assi3question4;
import java.util.Scanner;
public class assi3question4 {

	public static void main(String[] args) {
		

		        Scanner scan = new Scanner(System.in);

		        System.out.print("Enter a positive integer (0 to stop): ");
		        int num = scan.nextInt();

		        if (num == 0) {
		            System.out.println("No numbers were entered.");
		            return;
		        }

		        int max = num;
		        int min = num;
		        int sum = 0;
		        int count = 0;

		        while (num != 0) {
		            if (num > max) {
		                max = num;
		            }
		            if (num < min) {
		                min = num;
		            }

		            sum += num;
		            count++;

		            System.out.print("Enter a positive integer (0 to stop): ");
		            num = scan.nextInt();
		        }

		        double average = (double) sum / count;

		        System.out.println("Largest number: " + max);
		        System.out.println("Smallest number: " + min);
		        System.out.println("Average: " + average);
		    }
		}